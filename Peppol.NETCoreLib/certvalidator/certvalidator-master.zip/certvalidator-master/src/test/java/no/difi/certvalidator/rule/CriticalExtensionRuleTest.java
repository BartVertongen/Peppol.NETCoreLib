package no.difi.certvalidator.rule;

import org.testng.annotations.Test;

public class CriticalExtensionRuleTest {

    @Test
    public void simpleConstructor() {
        new CriticalExtensionRule();
    }

}
