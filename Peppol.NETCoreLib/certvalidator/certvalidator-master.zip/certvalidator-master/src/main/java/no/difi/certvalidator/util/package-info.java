/**
 * Some default implementations for easy use.
 */
package no.difi.certvalidator.util;