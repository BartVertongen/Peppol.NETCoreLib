/**
 * Rules implemented to suite specific needs worth sharing.
 */
package no.difi.certvalidator.extra;