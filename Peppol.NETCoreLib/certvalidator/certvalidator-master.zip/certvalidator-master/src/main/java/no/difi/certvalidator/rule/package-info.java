/**
 * Available rules for creation of certificate validator.
 */
package no.difi.certvalidator.rule;