/**
 * API for use and extension of validator library.
 */
package no.difi.certvalidator.api;