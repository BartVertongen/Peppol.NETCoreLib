package no.difi.certvalidator.api;

/**
 * @author erlend
 */
public interface Property<T> {
}
