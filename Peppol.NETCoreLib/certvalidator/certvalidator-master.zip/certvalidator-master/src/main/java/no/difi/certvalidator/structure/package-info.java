/**
 * Package for logical operations to create more advanced validators.
 */
package no.difi.certvalidator.structure;